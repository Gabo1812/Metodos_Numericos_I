% Examen I. Gabriel Alvarez Castrillo C00368 

% Problema 1
%{
a) Calcule el flujo de calor en funcion de x, q(x), con un distanciamiento 
∆x = 1,0 mm
b) Grafique q(x).
%}

%Solución:
%a)
clearvars;
%Primero abrimos y leemos el archivo
filename = "temperature_profile_data.dat";
data = readmatrix(filename);% Cargamos los datos
x = data(:,1); % Posición en metros
T = data(:,2); % % T. Kelvin

%Sea el coeficiente de conductividad térmica k_Cu lo siguiente
k_Cu = 384.1;
% Y la barra de cobre tiene un largo de 0.30 m y un diametro de 0.04 m
% Como piden con un distanciamiento de ∆x = 1 mm = 0.001 m,
% interpolo los datos con ese h
h = 0.001 ; 
xs = (x(1):h:x(end))';
Ts = zeros(size(xs)); 
%interpolo los datos
for i = 1:size(xs, 1)
    Ts(i) = spline_interpolation(x,T,xs(i));
end

figure(1)
plot(x,T, 'or', 'LineWidth', 1.5)
hold on;
plot(xs,Ts, '-k', 'LineWidth', 1.5)
hold off;
xlabel('Posición en x (m)')
ylabel ('Temperatura (K)')
legend('Data', 'Interpolación');
title('Interpolación con h = 0.001')

% Ahora tenemos que el flujo de calor q = -k_Cu dT/dx
% Por lo que tenemos que derivar la temperatura en función de la posición
flujo_calor =-k_Cu * dif_5_points1(xs,Ts,h);
%b)
figure(2)
plot(xs,flujo_calor,'-r', 'LineWidth', 1.5)
xlabel('Posición en x (m)')
ylabel ('Flujo de calor (W/m^2)')
title('Flujo de calor de la Ley de Fourier')






%{
Problema 2. 
Calcule el trabajo realizado sobre la masa m para desplazarla a lo largo
del eje x desde x_i = 0 hasta x_f = 20. 
%}

%{ 
Solución:
El trabajo es la integral definida respecto a x de la fuerza F (que esta en Newtons),
en los limites de  integración x_i = 0 hasta x_f = 20.
En este caso usaremos la rutina de integral de simpson adapt.
%}
x_i = 0;
x_f = 20;
tol = 1e-3;
%Habiendo definido la función que describe la fuerza en otra carpeta.
W = int_simpson_adapt(@f,x_i,x_f,tol);
%{
Por lo que, el trabajo realizado para desplazar una masa a lo largo
del eje x desde x_i = 0 hasta x_f = 20 es de 396.0252 Nm. 
%}

%{
Problema 3. 
a) Calcule el trabajo realizado para comprimir el gas He
 desde V_i = 0.001 hasta V_f = 1e-4. 
b) Compare la integral exacta con el resultado numerico
 a cuatro cifras significativas.
%}

%Solución:
%constantes dadas del problema
R = 8.31446261815324; % constante universal de gases J/(K*mol)
T =  307.15; % Temperatura en Kelvin 
a =  3.460e-3; % constante con unidades (J*m^2)/(mol^2) 
b =  2.380e-5; % constante con unidades (m^3)/(mol) 
n = 0.0250; % numero de moles de He
v_i = 0.001; % volumen inicial en m^3
v_f = 1e-4;  % volumen final en m^3
%{
a) R/
El trabajo es la integral definida respecto a V de la presión P,
en los limites de  integración V_i = 0.001 hasta V_f = 1e-4.
En este caso usaremos la rutina de integral de simpson adapt.
%}
W_gas = int_simpson_adapt(@P,v_i,v_f,tol);
% El trabajo realizado es de -146.6015 Nm, con una toleracia de 1e-3
%b) R/
W_gas_exc = Iexact(v_f) - Iexact(v_i);
% La integral exacta da -146.5723 Nm
%{
La diferencia entre ambas esta en 0.292 Nm, pero si se va disminuyendo
la toleración del simpson adapt se va acercando más y más al valor
exacto, para ser exacto con una tolerancia de 1e-8 ya el resultado
de la integral numerica por simpson adapt es igual al de la integral exacta
%}




