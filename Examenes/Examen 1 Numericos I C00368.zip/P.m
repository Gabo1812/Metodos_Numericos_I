function y = P(V)
R = 8.31446261815324; % constante universal de gases J/(K*mol)
T =  307.15; % Temperatura en Kelvin 
a =  3.460e-3; % constante con unidades (J*m^2)/(mol^2) 
b =  2.380e-5; % constante con unidades (J*m^2)/(mol^2) 
n = 0.0250; % numero de moles de He
y = (n*R*T)./(V-n*b) - (n*a)./V.^2;
end