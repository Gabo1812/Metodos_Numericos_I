function y = f(x)
y = 20*(1 - sin(5*x).*exp(-(x.^2)/10));
end