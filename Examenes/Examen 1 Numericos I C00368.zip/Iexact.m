function z =  Iexact(V)
    R = 8.31446261815324; % constante universal de gases J/(K*mol)
    T =  307.15; % Temperatura en Kelvin 
    a =  3.460e-3; % constante con unidades (J*m^2)/(mol^2) 
    b =  2.380e-5; % constante con unidades (J*m^2)/(mol^2) 
    n = 0.0250; % numero de moles de He
    z = R*T*n*log(V-b*n)+(a*n)/V; % obtenido con maxima
end