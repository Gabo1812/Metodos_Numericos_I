%Examen 2: Metodos Numericos
%Gabriel Alvarez Castrillo C00368
clearvars;
%Problema 1:
%Sea la función 
f = @(x,y) exp( (x/100)^2 + (y/50)^2  );
%Encerrada en el circulo x^2 + y^2 = 4. Este tendría radio r = 2.
% Por lo que los limites de la integral son de - sqrt(4-x^2)<y<- sqrt(4-x^2)
% Y -4<x<4
a = -2;
b = 2;
c =@(x) - sqrt(4-x^2);
d =@(x)  sqrt(4-x^2);
tol = 1e-5;
Int = int_doble_simpson_adapt_mod(f,a,b,c,d,tol); % I = 12.5717
disp(['La integral por Simpson Adapt. es: ', num2str(Int), ]);


