%Examen 2: Metodos Numericos
%Gabriel Alvarez Castrillo C00368
clearvars;
%Problema 2:
% Sacar inercia de pieza rectangular por Monte Carlo
% La pieza rectangular tiene dimensiones a = 0.02; %m, b = 0.04; %m
% y L = 0.25; %m
% Donde los a's son los limites en x, los b's los limites en y, los c's los
% limites en z
a = 0.02;%m
b = 0.04;%m
L = 0.25;%m

a1 = -L;%m los limites son de esta forma debido a como estan los ejes de la figura
a2 = 0;%m 
b1 = -b/2;%m
b2 = b/2;%m 
c1 = -a/2;%m
c2 = a/2;%m 
V = (a2-a1)*(b2-b1)*(c2-c1);%Volumen de integración
N = 1e7;

%Parte a) Con densidad uniforme de la forma:
p1 = @(x,y,z) 100; %Kg/m3
%Parte c) Con densidad variables de la forma:
p2 = @(x,y,z) 100*sech( (x-0.025)/L ); %Kg/m3
% Usando Monte Carlo vamos a hacer parte a y c a la vez para 
% ahorrar lineas de codigo

pix1 = 0;
piy1 = 0;
piz1 = 0;

pix2 = 0;
piy2 = 0;
piz2 = 0;

Fi = zeros(N,1);

for i=1:N
    x = (a2-a1)*rand(1)+a1;
    y = (b2-b1)*rand(1)+b1;
    z = (c2-c1)*rand(1)+c1;

    pix1 = pix1 + x^2*p1(x,y,z);
    pix2 = pix2 + x^2*p2(x,y,z);

    piy1 = piy1 + y^2*p1(x,y,z);
    piy2 = piy2 + y^2*p2(x,y,z);

    piz1 = piz1 + z^2*p1(x,y,z);
    piz2 = piz2 + z^2*p2(x,y,z);

    Fi(i) = (x^2 + y^2 + z^2)* p2(x, y, z);

end

sfx1 = (1/N)*pix1;
sfy1 = (1/N)*piy1;
sfz1 = (1/N)*piz1;

sfx2 = (1/N)*pix2;
sfy2 = (1/N)*piy2;
sfz2 = (1/N)*piz2;

Inercia_parte_a = V*(sfx1 + sfy1 + sfz1); % para densidad uniforme
Inercia_parte_c = V*(sfx2 + sfy2 + sfz2); % para densidad variable

%Parte b) Comparación con Maxima
%Además la masa para la densidad p1 es m = p1 * V = 0.02 Kg
m1 = 0.02; % kg
I_exact = @(x,y,z) (100/3)*(x*y*z)*(x^2 + y^2 + z^2); % obtenido en maxima
Inercia_exacta_1 = (I_exact(a2,b2,c2)-I_exact(a1,b1,c1)) + m1*(L/2)^2 ;

%El porcentaje de error se calcula como:
porcentaje_error_a = abs((Inercia_parte_a - Inercia_exacta_1) / Inercia_exacta_1) * 100;
disp(['Como se puede observar el porcetaje de diferencia de la parte "a)" entre la inercia calculada y exacta es: ', num2str(porcentaje_error_a),'%' ]);

%Calculo del error asociado de Monte Carlo para la parte c)

df = 0;
for i=1:N
    df = df + (Fi(i) - (sfx2 + sfy2 + sfz2))^2;
end
Error_Monte_Carlo = (V/sqrt(N))*sqrt((1/(N-1)*df)); % el error del Metodo de Monte Carlo


disp(['La inercia con densidad variable es: ', num2str(Inercia_parte_c), ' ± ', num2str(Error_Monte_Carlo)]);
% Además podemos apreciar que la Inercia con densidad variable es menor
% que con densidad uniforme, y esto es debido a que la densidad variable
% tiene una función que es creciente en el intervalo de -0.25 a 0, pero 
% siempre su cota superior es inferior al valor de la densidad uniforme (p1 = 100)
% y por lo tanto, como la densidad es menor, la inercia tambien será menor.
% Se puede ver el comportamiento en la siguiente grafica.

xc = linspace(-0.25, 0, 100); 
yc1 = 100*ones(size(xc));
yc2 = p2(xc);
figure(1);
plot(xc, yc1, '-r', 'LineWidth', 2);
hold on;
plot(xc, yc2, '-b', 'LineWidth', 2);
hold off;
xlabel('x');
ylabel('p(x)');
legend({'$p1(x) = 100$', '$p2(x) = 100 \cdot \mathrm{sech}\left( \frac{x - 0.025}{L} \right)$'}, 'Interpreter', 'latex');
title('Grafica de comparación de densidades');
grid on;

clear("df","Fi","i","N","pix1","pix2","piy1","piy2","piz1","piz2","sfx1","sfx2","sfy1","sfy2","sfz2","sfz1","xc","yc2","yc1","x","y","z")
