%Examen 2: Metodos Numericos
%Gabriel Alvarez Castrillo C00368
clearvars;
%Problema 3:
%Resuelva la siguiente ec. dif con RK4
%La ecuación a resolver es y' = 2*sin(20*t)*y^3 - y*t^3  , para el intervalo
% 0<= t <= 2 y y(0) = 1, con un h = 0.005.
a = 0;
b = 2;
N = 4e2;
h = 0.005; 
y = zeros(N,1);
t = zeros(N,1);
%condiciones iniciales
y(1) = 1; % y(0) = 1
t(1) = a; % t(0) = a

f = @(t,y) 2*sin(20*t)*y^3 - y*t^3;

%Usando la función de Runge Kutta 4 creada
[Y, T] = rk4(f,y,t,a,b,N);
% Gráfica 
figure(1)
plot(T, Y, '-r', 'LineWidth', 2);
xlabel('t');
ylabel('y(t)');
legend('y(t) obtenida');
title('Función obtenida por RK4 ');
grid on;