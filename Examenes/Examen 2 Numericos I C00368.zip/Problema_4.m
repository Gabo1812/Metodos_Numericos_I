%Examen 2: Metodos Numericos
%Gabriel Alvarez Castrillo C00368
clearvars;
%Problema 4:
%Sistema masa- resorte con amoriguamiento
%Resuelva la siguiente ec. dif con RK4
%La ecuación a resolver es x'' = -(R/m)*x' - (k/m)*x, donde la masa es
% m = 0.010 Kg, y desplazamos la masa una distancia de 0.10 m desde el
% el punto de equilibrio, con una constante del resorte k = 5 N/m
% para el intervalo
% 0<= t <= 5 y x(0) = 0.10 y x'(0) = 0, con un N = 1e4.

%Note que en este caso tenemos una ecuación diferencial de segundo orden
%Por lo que vamos a usar una función auxilar para se vuelva una de primer
%orden

%Sea la función auxiliar x' = z y x'' = z'
%Por lo que función queda como z' = -(R/m)*z - (k/m)*x
a = 0;
b = 5;
N = 1e4; 
h = (b-a)/N; 
xa = zeros(N,1);
za = zeros(N,1);
xb = zeros(N,1);
zb = zeros(N,1);
t = zeros(N,1);
%t = linspace(a, b, N+1)'% otra forma de definir t
% Y las condiciones iniciales son:
xa(1) = 0.10; % x(0) = 0.10
za(1) = 0; % x'(0) = 0
xb(1) = 0.10; % x(0) = 0.10
zb(1) = 0; % x'(0) = 0
t(1) = a; 
m = 0.010;%Kg
k = 5;%N/m
% Se resuelve para R = 0 y para R = 0.01 a la vez.
Ra = 0;
Rb= 0.01;
fa = @(t, xa, za) -(Ra/m)*za - (k/m)*xa;
fb = @(t, xb, zb) -(Rb/m)*zb - (k/m)*xb;
%Metodo de Runge Kutta 4
%Trabajamos las 2 ecuaciones diferenciales de las partes a) y c) a la vez
for i = 1:N-1

    kx1a = h * za(i);
    kz1a = h * fa(t(i), xa(i), za(i));
    
    kx1b = h * zb(i);
    kz1b = h * fb(t(i), xb(i), zb(i));

    kx2a = h * (za(i) + kz1a/2);
    kz2a = h * fa(t(i) + h/2, xa(i) + kx1a/2, za(i) + kz1a/2);
        
    kx2b = h * (zb(i) + kz1b/2);
    kz2b = h * fb(t(i) + h/2, xb(i) + kx1b/2, zb(i) + kz1b/2);

    kx3a = h * (za(i) + kz2a/2);
    kz3a = h * fa(t(i) + h/2, xa(i) + kx2a/2, za(i) + kz2a/2);

    kx3b = h * (zb(i) + kz2b/2);
    kz3b = h * fb(t(i) + h/2, xb(i) + kx2b/2, zb(i) + kz2b/2);

    kx4a = h * (za(i) + kz3a);
    kz4a = h * fa(t(i) + h, xa(i) + kx3a, za(i) + kz3a);

    kx4b = h * (zb(i) + kz3b);
    kz4b = h * fb(t(i) + h, xb(i) + kx3b, zb(i) + kz3b);
    
    xa(i+1) = xa(i) + (1/6) * (kx1a + 2*kx2a + 2*kx3a + kx4a);
    za(i+1) = za(i) + (1/6) * (kz1a + 2*kz2a + 2*kz3a + kz4a);
    
    xb(i+1) = xb(i) + (1/6) * (kx1b + 2*kx2b + 2*kx3b + kx4b);
    zb(i+1) = zb(i) + (1/6) * (kz1b + 2*kz2b + 2*kz3b + kz4b);

    t(i+1) = a + i*h;

end

figure(1);
plot(t, xa, '-b', 'LineWidth', 1.5);
hold on;
plot(t, xb, '-r', 'LineWidth', 1.5);
hold off;
xlabel('t');
ylabel('x(t)');
legend('x(t), con R=0','x(t), con R=0.01');
title('Solución x(t) usando RK4');
grid on;


