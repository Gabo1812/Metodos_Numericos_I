function du = f(t, u, dx, dy, dz, dvx, dvy, dvz)
    % Derivadas
    du = zeros(6, 1);
    du(1) = dx(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dx/dt = vx
    du(2) = dy(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dy/dt = vy
    du(3) = dz(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dz/dt = vz
    du(4) = dvx(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dvx/dt
    du(5) = dvy(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dvy/dt
    du(6) = dvz(t, u(1), u(2), u(3), u(4), u(5), u(6)); % dvz/dt
end