function [t, u] = runge_kutta_tres_variables_doble(x0, y0, z0, vx0, vy0, vz0, t0, tf, dt, dx, dy, dz, dvx, dvy, dvz)
    % Condiciones Iniciales
    u0 = [x0; y0; z0; vx0; vy0; vz0];
    
    % Número de Pasos
    N = floor((tf - t0) / dt);
    
    % Vector de Tiempo
    t = linspace(t0, tf, N);
    
    % Matriz Solución
    u = zeros(6, N);
    u(:, 1) = u0;
    
    % Solución
    for n = 1:N-1
        k1 = dt * f(t(n), u(:, n), dx, dy, dz, dvx, dvy, dvz);
        k2 = dt * f(t(n) + dt/2, u(:, n) + k1/2, dx, dy, dz, dvx, dvy, dvz);
        k3 = dt * f(t(n) + dt/2, u(:, n) + k2/2, dx, dy, dz, dvx, dvy, dvz);
        k4 = dt * f(t(n) + dt, u(:, n) + k3, dx, dy, dz, dvx, dvy, dvz);
        u(:, n+1) = u(:, n) + (k1 + 2*k2 + 2*k3 + k4) / 6;
    end
end