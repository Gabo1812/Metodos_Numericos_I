% Métodos Numéricos I
% Caso de Estudio: Péndulo de Foucault

% Gabriel Álvarez Castrillo - C00368
% Hernán Barquero Chaves - C10896
% Ángel Mendieta Rodríguez - C04801
% Samuel Piedra Araica - C15973

% Sea la aceleración de un sistema no inercial:
% a_r = g + \frac{kr - \alpha v - \beta v^2}{M} - 2 w \times v_r
% \vec{a_r} = g \hat{k} + \frac{k}{M} (-x,-y,z) - \frac{\alpha}{M} (\dot{x},\dot{y},\dot{z}) - \frac{\beta}{M} (\dot{x}^2, \dot{y}^2, \dot{z}^2) - 2 [- \dot{y} \omega sin \lambda, \dot{x} \omega sin \lambda, - \dot{y} \omega cos \lambda]

% donde:
% g = (0, 0, -g_0)
% F = -k(x, y, z)
% ω = (-ω_0 cosλ, 0, ω_0 senλ)
% v = (\dot{x}, \dot{y}, \dot{z})

% de donde se obtienen las siguientes aceleraciones
% \ddot{x} = \frac{-kx - \alpha \dot{x} - \beta \dot{x}^2 + 2\dot{y}\omega \sin \lambda
% \ddot{y} = \frac{-ky - \alpha \dot{y} - \beta \dot{y}^2 }{x} - 2\dot{M}\omega \sin \lambda
% \ddot{z} = g + \frac{kz - \alpha \dot{z} - \beta \dot{z}^2}{M} + 2\dot{y}\omega \cos \lambda

% y se asume que la altura del péndulo es aproximadamente constante porque
% no experimenta cambios en su velocidad y aceleración en la coordenada
% z, por lo que \ddot{z} = 0.

clearvars;

% Parámetros
eta = 1.8e-5; % Viscosidad del aire kg/(m·s)
rho = 1.225; % Densidad del aire Kg/m^3
cw = 0.47; % Coeficiente de resistencia cuadratica
r = 0.2; % Radio de la esfera del pendulo m
g = 9.80665; % Aceleración Gravitacional (m/s^2)
l = 67; % Longitud del Péndulo (m)
lambda = 1.38; % Colatitud en Costa Rica, San José
m = 20; % Masa del Péndulo Kg
k = 150; % Constante del Resorte N/m

a = 1.17e-1;% alpha de prueba para la simulación conceptual
%a = (3/2)*pi*r*eta;% alpha, valores más realistas tomando en cuenta más
%parametros

b = 2.26e-1;% beta de prueba para la simulación conceptual
%b = (1/2)*cw*pi*(r^2)*rho; % beta, valores más realistas tomando en cuenta más
%parametros 

w = 7.27e-2; % El de la Tierra es e-5 pero se usa esta para que se vea más rapido el efecto
%wr = 7.27e-5; % Velocidad Angular del Sistema de Referencia (rad/s) Tierra

% Se define el sistema de ecuaciones diferenciales
dx = @(t, x, y, z, vx, vy, vz) vx;
dy = @(t, x, y, z, vx, vy, vz) vy;
dz = @(t, x, y, z, vx, vy, vz) 0;
dvx = @(t, x, y, z, vx, vy, vz) 2*w*vy*sin(lambda) - k*x/m - a*vx/m - b*vx*vx/m;
dvy = @(t, x, y, z, vx, vy, vz) -2*w*vx*sin(lambda) - k*y/m - a*vy/m - b*vy*vy/m;
dvz = @(t, x, y, z, vx, vy, vz) 0;

% Condiciones Iniciales
x0 = 5.29; y0 = 2.47; z0 = -66.75;
vx0 = 0.11; vy0 = 4.21; vz0 = -2.22;
t0 = 0; tf = 65; dt = 0.01;

% Se resuelve el desplazamiento u usando runge kutta 4
[t, u] = runge_kutta_tres_variables_doble(x0, y0, z0, vx0, vy0, vz0, t0, tf, dt, dx, dy, dz, dvx, dvy, dvz);

% Se extraen las soluciones
x = u(1,:);
y = u(2,:);
z = u(3,:);

vx = u(4,:);
vy = u(5,:);
vz = u(6,:);

% Se grafica la trayectoria
figure(1);
plot3(x, y, z, '-b');
xlabel('x');
ylabel('y');
zlabel('z');
xlim([-10 7]);
ylim([-10 7]);
zlim([-66.75 0]);
title('Trayectoria del Péndulo');
grid on;

% Se grafica la energía
T = (1/2)*m*(vx.^2 + vy.^2 +vz.^2);
U = m*g.*(l+z) + (1/2)*k*((x.^2 + y.^2 +z.^2).^(1/2) - l).^2;

E = T + U;

figure(2);
plot(t,E, '-r', 'LineWidth', 1.5);
hold on;
plot(t,T, '-g', 'LineWidth', 1.5);
plot(t,U, '-b', 'LineWidth', 1.5);
hold off;
xlabel("Tiempo [s]");
ylabel("Energía [J]");
title('Energía del Péndulo');
grid on;

%{

En la energia total, (la señalada en rojo) podemos observar que la
energia disminuye continuamente debido a la resistencia del aire y otras
fuerzas disipativas presentes.

La energia cinetica, (la señalada en verde) oscila periodicamente debido al
movimiento del pendulo, y va perdiendo velocidad debido a la fricción hasta
que en el algun momento de la simulación queda en reposo (Es una oscilación amortiguada).

La energia potencial, (la señalada en azul) tiene oscilaciones en
contrafase con la de la energia cinetica, porque cuando la energia cinetica
es máxima, la potencial es minimo y viceversa.

%}

Simulacion_Pendulo(x,y,z);