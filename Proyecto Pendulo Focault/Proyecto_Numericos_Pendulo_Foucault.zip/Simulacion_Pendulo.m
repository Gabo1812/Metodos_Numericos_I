function Simulacion_Pendulo(x, y, z)
    figure;
    hold on;
    grid on;
    xlabel('Eje X');
    ylabel('Eje Y');
    zlabel('Eje Z');
    xlim([-10 8]);
    ylim([-10 8]);
    zlim([-70 0]);
    title('Animación del Péndulo de Foucault');
    
    % Establecer la vista para ver el plano xz claramente
    view([1 1 1]);
    
    % Graficar un punto fijo en (0, 0, 0)
    plot3(0, 0, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    
    % Variables para almacenar los objetos gráficos
    hLine = plot3(NaN, NaN, NaN, 'k');  % Inicializar la línea de conexión
    hPendu = plot3(NaN, NaN, NaN, '-b');  % Inicializar la trayectoria del péndulo
    hCircle = plot3(NaN, NaN, NaN, 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'r');  % Inicializar el círculo en el otro extremo
    
    % Animar la línea negra conectando (0,0,0) con cada punto (x,y,z)
    for i = 1:length(x)
        % Actualizar la línea de conexión
        set(hLine, 'XData', [0 x(i)], 'YData', [0 y(i)], 'ZData', [0 z(i)]);
        
        % Actualizar la trayectoria del péndulo
        set(hPendu, 'XData', x(1:i), 'YData', y(1:i), 'ZData', z(1:i));
        
        % Actualizar la posición del círculo
        set(hCircle, 'XData', x(i), 'YData', y(i), 'ZData', z(i));
        
        % Actualizar el gráfico
        drawnow;
        
        % Pausa para visualización
        pause(0.009);  % Puedes ajustar este valor para cambiar la velocidad de la animación
        
        % Borrar la línea anterior para que desaparezca
        if i > 1
            set(hLine, 'XData', NaN, 'YData', NaN, 'ZData', NaN);
        end
    end
    
    hold off;
end





