%Tarea 1 de Metodos Numericos
% Gabriel Alvarez Castrillo C00368
clearvars;
%Primero abrimos y leemos el archivo
filename = "thermistor_100K.dat";

A = readmatrix(filename);% Cargamos los datos
F = A(:,1); % T. Farenheit
C = A(:,2); % % T. Celcius
O = A(:,3); % Resistencia Ohms
Ohm = 1./1e3 *O; % para ponerlo en kilo ohms

%{
PROBLEMA 1: Mediante interpolación por polinomios de Lagrange,
 encuentre el valor de la temperatura, en Centıgrados, para 
los valores de resistencia de 79kΩ y 29kΩ.
%}

r1 = 79;
r2 = 29;  

%Para los valores de la temperatura en Celsius de esos valores de
%resistencia podemos hacer lo siguiente:

C_lagrange1 = lagrange_interpolation(Ohm,C,r1);
C_lagrange2 = lagrange_interpolation(Ohm,C,r2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ohmt = (Ohm(end):1:Ohm(1))'; % creamos puntos equidistantes dentro del rango de Ohms
Ctl = zeros(size(Ohmt,1), 1); % se crea lista llena de ceros hasta el tamaño de Ohmt

for i=1:size(Ohmt,1)
    Ctl(i) = lagrange_interpolation(Ohm,C,Ohmt(i));
end

figure(1);
title('Comparación de la función con la interpolación de Lagrange');
plot(Ohm,C,'ob');
hold on;
plot(Ohmt,Ctl,'.r')
hold off;
ylabel('Temeperatura (C)');
xlabel('Resistencia (k\Omega)');
xlim([0, 4000]);
ylim([-40, 100]); 
legend('Función', 'Interpolación de Lagrange'); 

% Parte a) ¿Que resultados obtuvo?

%{
R/ 
Para la resistencia de 79kΩ tenemos una temperatura de -5.79
x10^17 °C, y para la resistencia de 29kΩ tenemos 53.9 °C
%}

% Parte b) ¿Como explica los resultados obtenidos?

%{
 R/ 
 Esto puede ser porque cuando se utiliza un polinomio de grado muy alto
 para la interpolación, puede ocurrir un fenómeno conocido como 
 el fenómeno de Runge. 
 Esto puede llevar a tener un intervalo donde si coincida y después comience con 
 oscilaciones excesivas entre los puntos de datos, a diferencia de lo propuesto por
 el teorema de aproximaciones de Weierstrass, por lo que no siempre un grado mayor de n
 para el polinomio contribuye en la precisión de la aproximación.
 

%}
% Parte c) Adjunte los archivos de las rutina y funciones programadas.
%R/ Los archivos de rutina y las funciones programadas se pueden ver en este mismo
%arhivo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%{
PROBLEMA 2: Con la rutina de interpolacion por el Metodo de Nevilles, proceda a realizar
la interpolacion, de los valores de resistencia del Problema 1, con una precisi´on de
1 × 10−1.
%}

epsilon = 1e-1;
n = zeros(size(Ohm));
%Los valores de la temperatura a esas resistencias por Neville son:
C_neville1 = nevilles_interpolation(Ohm,C,r1,epsilon);
C_neville2 = nevilles_interpolation(Ohm,C,r2,epsilon);

%Ahora para crear una grafica de la interpolación
Ctv = zeros(size(Ohmt)); % Inicializar la lista de temperaturas interpoladas
for i=1:size(Ohmt,1)
    [Ctv(i),n(i)] = nevilles_interpolation(Ohm,C,Ohmt(i),epsilon);
end

figure(2);
title('Comparación de la función con la interpolación de Neville');
plot(Ohm,C,'ob');
hold on;
plot(Ohmt,Ctv,'.r');
hold off;
ylabel('Temeperatura (C)');
xlabel('Resistencia (k\Omega)');
legend('Función', 'Interpolación de Neville'); 


%}
% Parte a) ¿Que resultados obtuvo? 
%{
 R/ 
Para la resistencia de 79kΩ tenemos una temperatura de 30.11 °C y para
la resistencia de 29kΩ tenemos una temperatura de 53.64 °C.
%}

% Parte b) ¿Cual fue el grado del polinomio utilizado para la
% interpolacion de cada uno de los valores?

%R/ El polinomio es de grado maximo 113, es el maximo porque no siempre usa
%este grado de polinomio, empieza en grado 2 y va aumentando el grado (o
%lo mantiene) dependiendo del punto a aproximar.

% Parte c) ¿Como explica el resultado obtenido? 

%R/ Note que el resultado casi no falla comparado con Lagrange ya que usa polinomios
% de grados más bajos para pasar por todos los puntos de muestra.

% Parte d) Adjunte los archivos de las rutina y funciones programadas.

%R/ Los archivos de rutina y las funciones programadas se pueden ver en este mismo
%arhivo

% Parte e) Mediante prueba de variacion manual del orden de magnitud del valor de la
% precision, indique cual es precision maxima que se puede alcanzar y el grado 
% del polinomio de interpolacion para los dos valores de resistencia indicados.
%{
R/
La presición máxima que se puede obtener es de epsilon = 1e-1, y el grado maximo es de 113. 
%}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%{
PROBLEMA 3: Con la rutina de interpolacion por el Metodo de Spline, realice:
%}

%{
PROBLEMA 3: Con la rutina de interpolacion por el Metodo de Spline, realice:
%}

% Los valores de la temperatura a esas resistencias por Spline son:
C_spline1 = spline_interpolation(flipud(Ohm), flipud(C), r1);
C_spline2 = spline_interpolation(flipud(Ohm), flipud(C), r2);

% Ahora para crear una grafica de la interpolación
Ohmts = (Ohm(end):0.1:Ohm(1))';%creo otra solo para spline con saltos de 0.1 k ohms
%ya que tengo Ohm en kilo ohms
Cts = zeros(size(Ohmts)); 

for i = 1:size(Ohmts, 1)
    Cts(i) = spline_interpolation(flipud(Ohm),flipud(C),Ohmts(i));
end


figure(3);
title('Comparación de la función con la interpolación de Spline');
plot(Ohm,C,'ob');
hold on;
plot(Ohmts,Cts,'.r')
hold off;
ylabel('Temeperatura (C)');
xlabel('Resistencia (k\Omega)');
xlim([0, 4000]);
ylim([-40, 100]); 
legend('Función', 'Interpolación de Spline'); 


% Parte a) Realice una grafica de Temperatura en funcion de la Resistencia. 
% R/ Se puede observar en la  grafica doble de Temperatura en función de
% resistencia y la interpolación 

% Parte b) ¿Realice una interpolacion, para todos los datos, con un paso en los valores
%de resistencia de 100Ω.
%R/ Se puede observar arriba en el codigo

% Parte c) Realice la grafica Temperatura en funcion de la Resistencia de los datos con
%cırculos y los datos interpolados con puntos. 
%R/ Se puede observar en la  grafica doble de Temperatura en función de
% resistencia y la interpolación 

%{
Parte d) Adjunte los archivos de las rutina y funciones programadas.
R/ Los archivos de rutina y las funciones programadas se pueden ver en
este mismo arhivo, además note que a diferencia de Lagrange y Neville, el método de 
interpolación por spline funciona por completo en toda el rango de datos y utilizando
puntos de interpolación equidistantes, y funciona porque justamente este metodo 
fue construidos para limitar los efectos del fenómeno de Runge.
%}


