%Tarea 3: Gabriel Alvarez Castrillo C00368 
%Problema 3:
%Haciendo uso de Monte Carlo
clearvars;
L = 0.15; % m 
p = @(x,y,z) 10*(exp(-500*((x-0.01)^2 + (y+0.02)^2)) + (1/2)*(z+0.05));
p_c =@(x,y,z) 1;

%a) Usando una densidad constante p_c = 1

% La posición del centro de masa esta dado por:
a=-0.075;%m
b=0.075;%m
c=-0.075;%m
d=0.075;%m
e=-0.075;%m
f=0.075;%m
N = 1e5; %numeros de valores a probar
V = (b-a)*(d-c)*(f-e);%área de integración
x = rand(N,1);
y = rand(N,1);
z = rand(N,1);

pixc = 0;
piyc = 0;
pizc = 0;

Pixc = zeros(N,1);
Piyc = zeros(N,1);
Pizc = zeros(N,1);


for i=1:N
    x = (b-a)*rand(1)+a;
    y = (d-c)*rand(1)+c;
    z = (f-e)*rand(1)+e;

    pixc = pixc + x*p_c(x,y,z);
    Pixc(i) = x*p_c(x,y,z);

    piyc = piyc + y*p_c(x,y,z);
    Piyc(i) = y*p_c(x,y,z);

    pizc = pizc + z*p_c(x,y,z);
    Pizc(i) = z*p_c(x,y,z);
end

sfxc = (1/N)*pixc;
sfyc = (1/N)*piyc;
sfzc = (1/N)*pizc;

Intxc = V*sfxc;
Intyc = V*sfyc;
Intzc = V*sfzc;

% Note que como este caso la densidad es una constante igual a 1,el valor de
% la masa es igual al valor del volumen 
M = p_c(x)*V ;
X_CMc = Intxc/M; %
Y_CMc = Intyc/M; %
Z_CMc = Intzc/M; %

R_CMc =[X_CMc,Y_CMc,Z_CMc]; 

% b) Ahora usando la densidad variable

pix = 0;
piy = 0;
piz = 0;

Pix = zeros(N,1);
Piy = zeros(N,1);
Piz = zeros(N,1);


for i=1:N
    x = (b-a)*rand(1)+a;
    y = (d-c)*rand(1)+c;
    z = (f-e)*rand(1)+e;

    pix = pix + x*p(x,y,z);
    Pix(i) = x*p(x,y,z);

    piy = piy + y*p(x,y,z);
    Piy(i) = y*p(x,y,z);

    piz = piz + z*p(x,y,z);
    Piz(i) = z*p(x,y,z);
end

sfx = (1/N)*pix;
sfy = (1/N)*piy;
sfz = (1/N)*piz;

Intx = V*sfx;
Inty = V*sfy;
Intz = V*sfz;

%calculo de la masa 
mi = 0;
Mi = zeros(N,1);

for i=1:N
    x = (b-a)*rand(1)+a;
    y = (d-c)*rand(1)+c;
    z = (f-e)*rand(1)+e;

    mi = mi + p(x,y,z);
    Mi(i) = p(x,y,z);

end
sf = (1/N)*mi;
M1 = V*sf;

X_CM = Intx/M1; %
Y_CM = Inty/M1; %
Z_CM = Intz/M1; %

R_CM = [X_CM,Y_CM,Z_CM];


% Por lo que la posición del CM con densidad constante es R_CMc = [0,0,0]
% Y con densidad variable es R_CM = [0.008,-0.0154,0.0037]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Esto es algo extra estetico extra
%Para el cubo con densidad constante
vertices1 = [-L/2,-L/2,-L/2; L/2,-L/2,-L/2; L/2,L/2,-L/2; -L/2,L/2,-L/2;
            -L/2,-L/2,L/2; L/2,-L/2,L/2; L/2,L/2,L/2; -L/2, L/2, L/2];      
caras1 = [1 2; 2 3; 3 4; 4 1; 1 5; 2 6; 3 7; 4 8; 5 6; 6 7; 7 8; 8 5];  

% Coordenadas del centro del cubo con densidad variable

cx = R_CM(1);
cy = R_CM(2);
cz = R_CM(3);

vertices2 = [-L/2,-L/2,-L/2; L/2,-L/2,-L/2; L/2,L/2,-L/2; -L/2,L/2,-L/2; 
            -L/2,-L/2,L/2; L/2,-L/2,L/2; L/2,L/2,L/2; -L/2,L/2,L/2];      
vertices2(:,1) = vertices2(:,1) + cx;
vertices2(:,2) = vertices2(:,2) + cy;
vertices2(:,3) = vertices2(:,3) + cz;

% Conexiones de los vértices del cubo (caras)
caras2 = [1 2; 2 3; 3 4; 4 1; 1 5; 2 6; 3 7; 4 8; 5 6; 6 7; 7 8; 8 5];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(1);
plot3(R_CMc(1),R_CMc(2),R_CMc(3), 'ro', 'MarkerSize', 10, 'LineWidth', 1.5);
hold on;
plot3(R_CM(1),R_CM(2),R_CM(3), 'bo', 'MarkerSize', 10, 'LineWidth', 1.5);
plot3([R_CMc(1), R_CM(1)], [R_CMc(2), R_CM(2)], [R_CMc(3), R_CM(3)], 'k-', 'LineWidth', 2);

for i = 1:size(caras1, 1)
    plot3(vertices1(caras1(i,:), 1), vertices1(caras1(i,:), 2), vertices1(caras1(i,:), 3), 'r--', 'LineWidth', 1);
    hold on;
end

for i = 1:size(caras2, 1)
    plot3(vertices2(caras2(i,:), 1), vertices2(caras2(i,:), 2), vertices2(caras2(i,:), 3), 'b--', 'LineWidth', 1);
end

hold off;
grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');
text(R_CMc(1),R_CMc(2),R_CMc(3),'  CM \rho = 1')
text(R_CM(1),R_CM(2),R_CM(3),'  CM \rho (x,y,z)')

%Eliminando variables para facilitar la lectura en el workspace
clear cx cy cz caras1 caras2 vertices1 vertices2 Pix Piy Piz Pixc Piyc Pizc ;
clear Intx Inty Intz Intxc Intyc Intzc M M1 mi Mi 
clear sf sfx sfy sfz sfxc sfyc sfzc pix piy piz pixc piyc pizc




