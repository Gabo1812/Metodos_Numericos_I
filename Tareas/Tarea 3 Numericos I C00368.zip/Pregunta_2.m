%Tarea 3: Gabriel Alvarez Castrillo C00368 
%Problema 2:
clearvars;
g = @(x,y) 2.*(y.^2).*sin(x) + y.*(cos(x)).^2;

tol1 = 1e-6;
a1 = 0;
b1 = pi/4 ;
c1 = @(x) x;
d1 =@(x) exp(x); 
Ip2 = int_doble_simpson_adapt_mod(g,a1,b1,c1,d1,tol1);
%El resultado de esta integral es 1.6839
Ip2_exact = integral2(g,a1,b1,c1,d1); % usando la función propia de matlab
% Como se puede apreciar la integral es igual a la exacta