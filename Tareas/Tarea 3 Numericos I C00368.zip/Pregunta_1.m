%Tarea 3: Gabriel Alvarez Castrillo C00368 
%Problema 1.
clearvars;
a = 0;
b = 1;%limite intermedio que sale al separar
c = 2;
tol = 1e-4;

%Función a integrar
g = @(x) x.*log(x+1);
f = @(x) g(x)./((x-1).^(2/3));

%Note que hay una discontinuidad en x=1.
%Por lo que vamos a separar la integral en dos, una para la región de
% 1<x<2 y otra para la región de 0<x<1.
%Empezamos obteniendo el polinomio de Taylor de grado 4 para la region
% 1<x<2 y lo hacemos por definición.

%Utilizando Maxima para sacar las derivadas

dg_1 =@(x) log(x + 1) + x/(x + 1);%primera derivada
ddg_1 =@(x) 2/(x + 1) - x/(x + 1)^2;%segunda derivada
dddg_1 =@(x) (2*x)/(x + 1)^3 - 3/(x + 1)^2;%tercera derivada
ddddg_1 =@(x) 8/(x + 1)^3 - (6*x)/(x + 1)^4;%cuarta derivada

%Una vez calculadas las derivadas por Maxima, evaluamos en m=1
m = 1;
g_0m = g(m);
g_1m = dg_1(m);
g_2m = ddg_1(m);
g_3m = dddg_1(m);
g_4m = ddddg_1(m);

%Por lo tanto el polinomio de Taylor de grado 4 centrado en 1 es:

P4_1 = @(x) g_0m + g_1m .* (x - m) + g_2m .* (x - m).^2 / factorial(2) + g_3m .* (x - m).^3 / factorial(3) + g_4m .* (x - m).^4 / factorial(4);

% Por lo que el polinomio de Taylor de grado 4 que aproxima g(x) es:
% P4(x) = (671682149720991*x)/562949953421312 + (3*(x - 1)^2)/8 - (x - 1)^3/12 + (5*(x - 1)^4)/192 - 4503599627370497/9007199254740992;

%Ahora calculamos la integral para esta región 1<x<2 

h1 = @H1;
f1 = @G1; %(x*log(x+1)-P4)/((x-1)^(2/3))

I1 = int_simpson_adapt(h1,b,c,tol);
I2 = int_simpson_adapt(f1,b,c,tol);

I_sup = I1 + I2; % Integrales en la región 1<x<2

%Ahora continuamos en la región de 0<x<1, para ello haremos el
%cambio de variable x = -x y al hacerlo los limites cambia a -1<x<0

gb = @(x) -x.*log(-x+1);
fb = @(x) gb(x)./((x+1).^(2/3));

%Note que hay una discontinuidad en x = -1
%Para obtener el polinomio de Taylor de grado 4 lo hacemos por definición
%Utilizando Maxima para sacar las derivadas

dg_2 =@(x) x/(1-x)-log(1-x);
ddg_2 =@(x) x/(1-x)^2+2/(1-x);
dddg_2 =@(x) (2*x)/(1-x)^3+3/(1-x)^2;
ddddg_2 =@(x) (6*x)/(1-x)^4+8/(1-x)^3;

%Una vez calculadas las derivadas por Maxima, evaluamos en n=-1

n = -1;
g_0mb = gb(n);
g_1mb = dg_2(n);
g_2mb = ddg_2(n);
g_3mb = dddg_2(n);
g_4mb = ddddg_2(n);

%Por lo tanto el polinomio de Taylor de grado 4 centrado en -1 es:
P4_2 = @(x) g_0mb + g_1mb.*(x-m) + g_2mb.*(x-m).^2/factorial(2) + g_3mb.*(x-m).^3/factorial(3) + g_4mb.*(x-m).^4/factorial(4);
%P4(x) = (671682149720991*x)/562949953421312 + (3*(x - 1)^2)/8 - (x - 1)^3/12 + (5*(x - 1)^4)/192 - 4503599627370497/9007199254740992;

h2 = @H2;
f2 = @G2; %(-x*log(-x+1)-P4)/((-x-1)^(2/3))

I3 = int_simpson_adapt(h2,-b,a,tol);
I4 = int_simpson_adapt(f2,-b,a,tol);

I_inf = I3 + I4; %Integral inferior para la región de 0<x<1 

Int = I_sup + I_inf; % Integral que buscabamos

% Donde la integral usando esta aproximación nos da 4.1649 aproximadamente
%Eliminando variables para facilitar la lectura en el workspace
clear ddddg_1 ddddg_2 dddg_1 dddg_2 ddg_1 ddg_2 dg_1 dg_2;
clear g_0mb g_0m g_1m g_1mb g_2m g_2mb g_3m g_3mb g_4m g_4mb;





