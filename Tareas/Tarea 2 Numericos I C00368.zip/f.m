function y =f(t)
t = t*60;
n=5;
f = 0.03;
w = 2*pi*f;
y = 0;
for k=1:n
    y = y + (4/pi)*(sin((2*k-1)*w*t))/(2*k-1) + (-2/pi)*(power((-1),k)/k)*sin(w*k*t);
end
y = 3.24*y;

for i=1:size(y,1)
    if y(i)<=0
        y(i) = 0.32*y(i);
    end
end
end