%Tarea 2 Gabriel Alvarez Castrillo C00368
 clearvars;
 %Primero abrimos y leemos el archivo
 filename = "volumen_signal.dat";
 A = readmatrix(filename);% Cargamos los datos
 t = A(:,1); % Tiempo
 V = A(:,2); % % Volumen
 
%Problema 1.
% a) Grafique los datos y verifique si los datos fueron adquiridos de forma
% periodica (h = constante).
 %R/
figure(1)
plot(t,V, '-b')
xlabel("Tiempo (s)")
ylabel("Volumen (L)")
diferencias = diff(t);% Calcula las diferencias entre cada par de puntos consecutivos
%como se puede ver las diferencias entre puntos adyacentes representan el h
% pero en esta caso tenemos que h no es constante


% b) Realice la interpolacion adecuada, se sugiere Spline, con el fin de interpolar
% los datos suministrados en forma periodica, indique el h sugerido.
%R/
h = mean(diferencias); % Escogi este h = 0.0050

ts = (t(1):h:t(end))';
Vs = zeros(size(ts)); 
%interpolo los datos
for i = 1:size(ts, 1)
 Vs(i) = spline_interpolation(t,V,ts(i));
 end

% c) Derive la señal para obtener flujo en funcion del tiempo, mediante los
% Metodos de 3 y 5 Puntos. Grafique los resultados y compare.
%R/

%Usando el metodo de derivación en 3 puntos tenemos:
flujo3p = dif_3_points(ts,Vs,h);

%Usando el metodo de derivación en 5 puntos tenemos:
flujo5p = dif_5_points1(ts,Vs,h);

figure(2)
plot(ts,Vs, '-b', 'LineWidth', 1.5);
hold on;
plot(ts,flujo3p, ' -r', 'LineWidth', 1.5);
plot(ts,flujo5p, ' og');
hold off;
legend('Función', 'Diff 3 puntos','Diff 5 puntos');
xlabel("Tiempo (s)")



%Problema 2.
% a) Grafique el flujo en funcion del tiempo y identifique el flujo de gas aspirado
%(flujo positivo) y el flujo expirado (flujo negativo).

%R/
x = (0:0.0001:5)'; 
y = f(x);

x1 = x(x <= 0.2778); %flujo aspirado
x2 = x(x > 0.2778 & x <= 0.5556);%flujo expirado
x3 = x(x > 0.5556);

y1 = f(x1);
y2 = f(x2);
y3 = f(x3);

% Grafica de la función donde se muestra inhalación y exhalación
figure(3)

plot(x1, y1, 'r', 'LineWidth', 1.5)  
hold on 
plot(x2, y2, 'b', 'LineWidth', 1.5)  
plot(x3, y3, 'k', 'LineWidth', 1.5)  
hold off  
title('Gráfica de la función de flujo')
xlabel('Tiempo (min)')
ylabel('Flujo (L/min)')
legend('inhalación', 'exhalación', 'función')
grid on

% b) Escoja apropiadamente el intervalo para calcular el volumen aspirado y el
%volumen expirado mediante integracion numerica.
% El intervalo de aspiración es de [0,0.2778] y el de expiración
% es de [0.2778,0.5556]

%R/
a=0;
b=0.2778;
c=0.5556;
n=1e3;
int_a = int_trapezoide(a,b,n);
int_e = int_trapezoide(b,c,n);
ints_a = int_simpson(a,b,n);
ints_e = int_simpson(b,c,n);

% c) Reporte los dos volumenes calculados.
% El volumen para inhalación es 1.2835 L
% El volumen para exhalación es 0.4107 L





