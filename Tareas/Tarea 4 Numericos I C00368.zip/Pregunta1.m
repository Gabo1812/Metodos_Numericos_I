%Tarea 4: Metodos Numericos
%Gabriel Alvarez Castrillo C00368

%Problema 1:
%Resuelva la siguiente ec. dif con RK4
%La ecuación a resolver es y' = -ty + 4t/y , para el intervalo
% 0<= t <= 1 y y(0) = 1, con un h = 0.01.

clearvars;
a = 0;
b = 1;
N = 1e2;
%h = (b-a)/N; así se define formalmente
h = 0.01; 
y = zeros(N,1);
t = zeros(N,1);
%t = (a:h:b)'; % otra forma de definir t
%condiciones iniciales
y(1) = 1; % y(0) = 1
t(1) = a; % t(0) = a

f = @(t,y) -t.*y + 4.*(t./y) ;
%Metodo de Runge Kutta 4
for i = 1:N-1
    k1 = h * f(t(i) , y(i));
    k2 = h * f(t(i) + (1/2)*h , y(i) + (1/2)*k1);
    k3 = h * f(t(i) + (1/2)*h , y(i) + (1/2)*k2);
    k4 = h * f(t(i) + h , y(i) + k3);
    y(i+1) = y(i) + (1/6)*(k1 + 2*k2 + 2*k3 + k4);
    t(i+1) = a + i*h; 
end


%vamos a hacer una comparación con la función exacta
y_exact = @(t) sqrt(4 - 3 * exp(-t.^2));
y_exact_values = y_exact(t);


% Gráfica comparativa
figure(1)
hold on;
plot(t, y, 'or');
plot(t, y_exact_values, '-k', 'LineWidth', 1.5);
hold off;
xlabel('t');
ylabel('y(t)');
legend('y(t) obtenida', '$y(t) = \sqrt{4 - 3 e{-t^2} }$', 'Interpreter', 'latex');
title('Comparación entre función obtenida y exacta');
grid on;


%Por como se puede observar en la grafica, el metodo de Runge Kutta
%nos dio como la función exacta