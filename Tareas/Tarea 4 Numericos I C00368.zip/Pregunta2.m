%Tarea 4: Metodos Numericos
%Gabriel Alvarez Castrillo C00368

%Problema 2:
%Resuelva la siguiente ec. dif con RK4
%La ecuación a resolver es y'' = (1-y^2)*y' - y, para el intervalo
% 0<= t <= 10 y y(0) = y'(0) = 1, con un h = 0.01.

%Note que en este caso tenemos una ecuación diferencial de segundo orden
%Por lo que vamos a usar una función auxilar para se vuelva una de primer
%orden

%Sea la función auxiliar y' = z y y'' = z'
%Por lo que función queda como z' = (1-y^2)*z - y

clearvars;
a = 0;
b = 10;
N = 1e3; % queda bonita con 1e3 pero realmente deberia ser 1e2 para que de ese h
%h = (b-a)/N; así se define formalmente
h = 0.01; 
y = zeros(N,1);
z = zeros(N,1);
t = zeros(N,1);
%t = linspace(a, b, N+1)'% otra forma de definir t
% Y las condiciones iniciales son:
y(1) = 1; % y(0) = 1
z(1) = 1; % y'(0) = 1
t(1) = a; 
f = @(t, y, z) (1 - y^2) * z - y;
%Metodo de Runge Kutta 4
%Trabajamos las 2 ecuaciones diferenciales a la vez
for i = 1:N-1

    ky1 = h * z(i);
    kz1 = h * f(t(i), y(i), z(i));
    
    ky2 = h * (z(i) + kz1/2);
    kz2 = h * f(t(i) + h/2, y(i) + ky1/2, z(i) + kz1/2);
    
    ky3 = h * (z(i) + kz2/2);
    kz3 = h * f(t(i) + h/2, y(i) + ky2/2, z(i) + kz2/2);
    
    ky4 = h * (z(i) + kz3);
    kz4 = h * f(t(i) + h, y(i) + ky3, z(i) + kz3);
    
    y(i+1) = y(i) + (1/6) * (ky1 + 2*ky2 + 2*ky3 + ky4);
    z(i+1) = z(i) + (1/6) * (kz1 + 2*kz2 + 2*kz3 + kz4);
    t(i+1) = a + i*h;
end


figure(1);
plot(t, y, '-b', 'LineWidth', 1.5);
xlabel('t');
ylabel('y(t)');
title('Solución y(t) usando RK4');
grid on;

