%Tarea 4: Metodos Numericos
%Gabriel Alvarez Castrillo C00368

%Problema 3:
%Se tiene un campo magnetico de la forma B = [0,0,B_z], con B_z = 1 T.
%Si se tiene un electron con una energia cinetica de 20 keV con una
%dirección n = 1/sqrt(3) [1,1,1]

clearvars;

%Constantes a utilizar:
e = 1.602e-19; %C
m = 9.109e-31; %Kg
epsilon_0 = 8.854e-12; %C^2/(N*m^2)
q = -1*e; %C
%Definción de parametros a utilizar
ti = 0;
tf = 1e-9;
N = 1e5;
h = (tf-ti)/N;

B_z = 1; %magnintud en Teslas
B = [0,0,B_z]; % Campo Magnetico constante

%Posición inicial
r0 = [0,0,0]; % Sale del origen 
t = zeros(N,1);% Ojo puede que haya que cambiarlo

%Para la parte a)

%Velocidad inicial
%T = 20e3;% eV la pasamos a Nm
T = 3.2043e-15;% Nm
V = sqrt((2*T)/m); % m/s
V0 = V*[1,1,1]/sqrt(3); % vector de velocidad inicial normalizado
r = zeros(N,3);
v = zeros(N,3);
v(1,:) = V0;
r(1,:) = r0; 

%Para la parte b)

% Para la parte b) tenemos que cambiar la energía cinetica para que el
%ciclotron tenga radio r = 2e-5 m
r_c = 2e-5; %m
%La energia cinetica de un ciclotron se define como:
Tb = (q^2 * B_z^2 *r_c^2)/(2*m); % nueva energia cinetica

Vb = sqrt((2*Tb)/m); % m/s
V0b = Vb*[1,1,1]/sqrt(3); % vector de velocidad inicial normalizado
vb = zeros(N,3);
rb = zeros(N,3);
vb(1,:) = V0b;
rb(1,:) = r0; 

% La ecuación a resolver es v' = (q/m)*cross(v,B)

for i=1:N-1
    
    k1 = h*(q/m)*cross(v(i,:),B);
    k1b = h*(q/m)*cross(vb(i,:),B);

    k2 = h*(q/m)*cross(v(i,:)+k1/2,B);
    k2b = h*(q/m)*cross(vb(i,:)+k1b/2,B);

    k3 = h*(q/m)*cross(v(i,:)+k2/2,B);
    k3b = h*(q/m)*cross(vb(i,:)+k2b/2,B);

    k4 = h*(q/m)*cross(v(i,:)+k3,B);
    k4b = h*(q/m)*cross(vb(i,:)+k3b,B);

    v(i+1,:) = v(i,:)+(1/6)*(k1+2*k2+2*k3+k4);
    vb(i+1,:) = vb(i,:)+(1/6)*(k1b+2*k2b+2*k3b+k4b);

    k1 = h*v(i,:);
    k1b = h*vb(i,:);

    k2 = h*(v(i,:) + k1/2);
    k2b = h*(vb(i,:) + k1b/2);

    k3 = h*(v(i,:) + k2/2);
    k3b = h*(vb(i,:) + k2b/2);

    k4 = h*(v(i,:) + k3);
    k4b = h*(vb(i,:) + k3b);

    r(i+1,:) = r(i,:)+(1/6)*(k1+2*k2+2*k3+k4);
    rb(i+1,:) = rb(i,:)+(1/6)*(k1b+2*k2b+2*k3b+k4b);

    t(i+1) = i*h;
end

figure(1);
clf(1);
plot3(r0(1),r0(2),r0(3),'o','Color','g','MarkerFaceColor','k');
hold on;
plot3(r(:,1),r(:,2),r(:,3),'-','Color','k');
hold off;
grid on;
xlabel('x(m)');
ylabel('y(m)');
zlabel('z(m)');
text(0,0,0,'\leftarrow t = 0');
text(r(end,1),r(end,2),r(end,3),['\leftarrow t = ',num2str(t(end-1))]);
title('Trayectoria del electron parte a)');

figure(2);
clf(2);
plot3(r0(1),r0(2),r0(3),'o','Color','g','MarkerFaceColor','k');
hold on;
plot3(rb(:,1),rb(:,2),rb(:,3),'-','Color','k');
hold off;
grid on;
xlabel('x(m)');
ylabel('y(m)');
zlabel('z(m)');
text(0,0,0,'\leftarrow t = 0');
text(rb(end,1),rb(end,2),rb(end,3),['\leftarrow t = ',num2str(t(end-1))]);
title('Trayectoria del electron parte b)');



%Parte c)
% Y la frecuencia de oscilación es:
frecuencia = (abs(q)*B_z)/(2*pi*m); % aprox. 2.8 e10 1/s o 28 GHz


